###################
library(data.table)
library(haven)
library(ggmap)
library(maps)
library(ggplot2)
library(stargazer)
library(stringr)
library(gridExtra)
library(ggpubr)


# the mapping code below starts with the data.frame "moves"
# "moves" contains an origin lat/lon and a destination lat/lon
# for each of the 1078 international mover portfolio companies

# world map
# overlay the visualization on a world map
world <- map_data('world')
world <- subset(world,region!="Antarctica") #Delete Antarctic
# cross national (detailed location) moves
moves_n <- moves[,list(ties=.N),by=list(lon_orig=round(lon_orig,digits=0),
                                        lat_orig=round(lat_orig,digits=0),
                                        lon_dest=round(lon_dest,digits=0),
                                        lat_dest=round(lat_dest,digits=0))]
moves_n[,west := ( (lon_orig > lon_dest) & !is.na(lon_orig) & !is.na(lon_dest))]
moves_n[,east := ( (lon_orig <= lon_dest) & !is.na(lon_orig) & !is.na(lon_dest))]
moves_n[,sum(ties),by=.(west,east)]
casesW <- moves_n[west==1,sum(ties)]
casesE <- moves_n[east==1,sum(ties)]
cases <- nrow(moves)
ggplot() +
  geom_polygon(dat=world, aes(long, lat,group=group ), color="grey", fill="grey80") +
  geom_curve(data=moves_n, 
             aes(x=lon_orig*.999, y=lat_orig*.999, xend=lon_dest, yend=lat_dest,color=west,size=ties),
             alpha = 0.15,curvature=.25) +
  labs(title = "", x = "", y = "", color = (paste(cases,"International Moves:"))) +
  guides(colour = guide_legend(override.aes = list(size=5,alpha = .7))) +
  scale_size_continuous(range=c(.5, 2.5), guide=FALSE) +
  scale_color_brewer(labels = c((paste(casesW,"Westward")), (paste(casesE,"Eastward")) ),palette = "Set1") +
  theme_void() +
  theme(legend.position = "top") 
#ggsave("global_move.png",width=6,height=4,units="in")  
    
