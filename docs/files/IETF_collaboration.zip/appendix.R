rm(list=ls())
gc(reset=TRUE)

library(stargazer)
library(ggplot2)
library(readstata13)
library(data.table)
library(gridExtra)
library(lutz)
library(maps)
library(geosphere)




# inputs
baseline <- fread(input="drafts.csv")
authors <- fread(input="drafts_authors.csv")  
# idfile level author pairs
pairs <- merge(authors,authors,by="idfile",allow.cartesian = T)
# reduce to n*(n-1) pairs by draft
pairs <- pairs[authid.x < authid.y ]
# ellipsoidal distance in miles
pairs[,dist := distGeo( matrix(c(lon.x,lat.x),ncol=2), matrix(c(lon.y,lat.y),ncol=2) ) * .000621371]
pairs[is.na(dist), dist := 0]
# time zones
pairs[,tz.x := tz_lookup_coords(lat.x,lon.x)]
pairs[,tz.y := tz_lookup_coords(lat.y,lon.y)]



# APPENDIX ITEMS


# FIGURE 1: histogram of co-author counts
ggplot(baseline, aes(auth_n)) + 
  geom_histogram(stat="count") +  
  labs( y="Count", x="Draft Co-Authors", 
        title="Co-Author Count Histogram") +
  scale_x_continuous(breaks=c(0,2,4,6,8,10))

# FIGURE 2: team size and success
ggplot(baseline, aes(auth_n,as.integer(published))) + 
  stat_summary() +
  labs( y="Published", x="Draft Co-Authors", 
        title="Mean Publication Rate by Team Size") +
  scale_x_continuous(breaks=c(0,2,4,6,8,10))

# FIGURE 3:  values of IVs
ggplot(baseline, aes(auth_n,auth_dorg)) +
  stat_summary() + 
  labs( y="Auth Diff Org Index", x="Draft Co-Authors", 
        title="Mean Org Dispersion by Team Size") +
  scale_x_continuous(breaks=c(0,2,4,6,8,10))

# FIGURE 4:  values of IVs
ggplot(baseline, aes(auth_n,auth_remote)) +
  stat_summary() +
  labs( y="Auth Remote Index", x="Draft Co-Authors", 
        title="Mean Remoteness by Team Size") +
  scale_x_continuous(breaks=c(0,2,4,6,8,10))

# FIGURE 5: process efficiency
ggplot(baseline, aes(auth_n,versions)) +
  stat_summary(aes(shape = as.character(published))) + 
  labs( y="Versions", x="Draft Co-Authors", 
        title="Process Efficiency - Mean Versions by Team Size") +
  scale_shape_discrete(name ="Draft Type",labels=c("Failed","Published")) + 
  scale_x_continuous(breaks=c(0,2,4,6,8,10))

# FIGURE 6: process efficiency
ggplot(baseline, aes(auth_n,duration)) +
  stat_summary(aes(shape = as.character(published))) + 
  labs( y="Duration", x="Draft Co-Authors", 
        title="Process Efficiency - Mean Duration by Team Size") +
  scale_shape_discrete(name ="Draft Type",labels=c("Failed","Published")) + 
  scale_x_continuous(breaks=c(0,2,4,6,8,10))


# FIGURE 7: author links map
world <- map_data('world')
world <- subset(world,region!="Antarctica") #Delete Antarctica
ggplot(pairs[!is.na(lon.x) & !is.na(lon.y)])+
  geom_polygon(dat=world, aes(long, lat,group=group ), color="grey", fill="grey80",alpha=.001) +    
  geom_segment(aes(x=lon.x,y=lat.x,xend=lon.y,yend=lat.y),
               alpha=.01,size=.3,color="blue") +
  labs( y="", x="", title="Author links") 

# FIGURE 8: histogram of distances
pairs[,dist100 := floor(pairs$dist/100)*100]
pairs[dist100 > 6000, dist100 := 6000]
ggplot(pairs[!is.na(lon.x) & !is.na(lon.y)], aes(dist100)) + 
  geom_histogram(stat="count") +
  labs( y="Count", x="Distance in 100 mile buckets", 
        title="Author Distance Histogram") 

# FIGURE 9: distance and same organization
pairs[,org_same := as.integer(rootemail.x == rootemail.y)]
pairs[is.na(org_same), org_same := 0]
ggplot(pairs[!is.na(lon.x) & !is.na(lon.y)], aes(dist100,org_same)) + 
  stat_summary() +
  labs( y="Mean Same Organization", x="Distance in 100 mile buckets", 
        title="Author Distance and Same Organization") 

# FIGURE 10: distance and same timezone
pairs[,tz_same := as.integer(tz.x == tz.y)]
pairs[is.na(tz_same), tz_same := 0]
ggplot(pairs[!is.na(lon.x) & !is.na(lon.y)], aes(dist100,tz_same)) + 
  stat_summary() +
  labs( y="Mean Same Time Zone", x="Distance in 100 mile buckets", 
        title="Author Distance and Time Zone") 

# FIGURE 11: distance and same nation
pairs[,nat_same := as.integer(nation.x == nation.y)]
ggplot(pairs[!is.na(lon.x) & !is.na(lon.y)], aes(dist100,nat_same)) + 
  stat_summary() +
  labs( y="Mean Same Nation", x="Distance in 100 mile buckets", 
        title="Author Distance and Same Nation") 

# FIGURE 12: VERSION distance spec map
# distance loops
coeffs <- data.table(
  Mbeta=double(),
  Mse=double(),
  Ibeta=double(),
  Ise=double(),
  rsq=double(),
  distance=double()
)
for(i in seq(from=10, to=6000, by=10)){
  dist <- pairs[,list(remoteN = mean(dist >= i)),idfile]
  test <- merge(baseline,dist,by="idfile")
  m2 <- lm(versions ~ remoteN*published + auth_dorg*published + 
             auth_us + auth_prior + org_presence +
             lnfilesize + prior_pubs + simul_drafts + as.factor(auth_n) + wg_submission + 
             key_count + key_novelty + combo_novelty + as.factor(date2) , data=test)  
  temp <-  data.table(Mbeta = summary(m2)$coefficients[2,1],
                      Mse = summary(m2)$coefficients[2,2],
                      Ibeta = summary(m2)$coefficients[50,1],
                      Ise = summary(m2)$coefficients[50,2],
                      rsq = summary(m2)$r.squared,
                      distance=i
  )
  coeffs <- rbind(coeffs,temp)
}
p1 <- ggplot(coeffs, aes(x=distance,y=Mbeta)) + 
  geom_errorbar(aes(ymin=Mbeta-1.96*Mse, ymax=Mbeta+1.96*Mse), width=.01,alpha=.3) +
  geom_point() + 
  labs(title="Auth Remote: Coeff and 95% CI", y="", x="") + 
  xlim(0, 6000) +
  geom_vline(xintercept =2500, color="black") +
  geom_hline(yintercept = 0, color="blue") 
p2 <- ggplot(coeffs, aes(x=distance,y=Ibeta)) + 
  geom_errorbar(aes(ymin=Ibeta-1.96*Ise, ymax=Ibeta+1.96*Ise), width=.01,alpha=.3) +
  geom_point() + 
  labs(title="Published X Auth Remote: Coeff and 95% CI", y="", x="") + 
  xlim(0, 6000) +
  geom_vline(xintercept =2500, color="black") +
  geom_hline(yintercept = 0, color="blue") 
p3 <- ggplot(coeffs, aes(x=distance,y=rsq)) +
  labs( title ="Model R-Squared", y= "", x="Pairwise Distance Threshhold") + 
  xlim(0, 6000) +
  geom_vline(xintercept =2500, color="black") +
  scale_y_continuous(breaks=c(.3120,.3130)) +
  theme(axis.text.y = element_text( angle=65)) + 
  geom_point() 
tp <- grid.arrange(p1,p2,p3)


# FIGURE 13: DURATION distance spec map
# distance loops
coeffs <- data.table(
  Mbeta=double(),
  Mse=double(),
  Ibeta=double(),
  Ise=double(),
  rsq=double(),
  distance=double()
)
for(i in seq(from=10, to=6000, by=10)){
  dist <- pairs[,list(remoteN = mean(dist >= i)),idfile]
  test <- merge(baseline,dist,by="idfile")
  m2 <- lm(duration ~ remoteN*published + auth_dorg*published + 
             auth_us + auth_prior + org_presence +
             lnfilesize + prior_pubs + simul_drafts + as.factor(auth_n) + wg_submission + 
             key_count + key_novelty + combo_novelty + as.factor(date2) , data=test)  
  temp <-  data.table(Mbeta = summary(m2)$coefficients[2,1],
                      Mse = summary(m2)$coefficients[2,2],
                      Ibeta = summary(m2)$coefficients[50,1],
                      Ise = summary(m2)$coefficients[50,2],
                      rsq = summary(m2)$r.squared,
                      distance=i
  )
  coeffs <- rbind(coeffs,temp)
}
p1 <- ggplot(coeffs, aes(x=distance,y=Mbeta)) + 
  geom_errorbar(aes(ymin=Mbeta-1.96*Mse, ymax=Mbeta+1.96*Mse), width=.01,alpha=.3) +
  geom_point() + 
  labs(title="Auth Remote: Coeff and 95% CI", y="", x="") + 
  xlim(0, 6000) +
  geom_vline(xintercept =2500, color="black") +
  geom_hline(yintercept = 0, color="blue") 
p2 <- ggplot(coeffs, aes(x=distance,y=Ibeta)) + 
  geom_errorbar(aes(ymin=Ibeta-1.96*Ise, ymax=Ibeta+1.96*Ise), width=.01,alpha=.3) +
  geom_point() + 
  labs(title="Published X Auth Remote: Coeff and 95% CI", y="", x="") + 
  xlim(0, 6000) +
  geom_vline(xintercept =2500, color="black") +
  geom_hline(yintercept = 0, color="blue") 
p3 <- ggplot(coeffs, aes(x=distance,y=rsq)) +
  labs( title ="Model R-Squared", y= "", x="Pairwise Distance Threshhold") + 
  xlim(0, 6000) +
  geom_vline(xintercept =2500, color="black") +
  scale_y_continuous(breaks=c(.2096,.2104)) +
  theme(axis.text.y = element_text( angle=65)) + 
  geom_point() 
tp <- grid.arrange(p1,p2,p3)


# FIGURE 14: Version country pair heatmap
hpairs <- merge(pairs[nation.x != "" & nation.y != "",list(idfile,nation.x,nation.y)],
                 baseline[,list(idfile,versions,duration,auth_n,published)],
                 by="idfile")
hpairs[,natN.x := .N,nation.x]
hpairs[,natN.y := .N,nation.y]
hpairs <- hpairs[natN.x > 500 & natN.y > 500]
hpairs[nation.x == "us", nation.x := "usa"]
hpairs[nation.x == "united kingdom", nation.x := "uk"]
hpairs[nation.x == "korea, republic of", nation.x := "korea"]
hpairs[nation.y == "us", nation.y := "usa"]
hpairs[nation.y == "united kingdom", nation.y := "uk"]
hpairs[nation.y == "korea, republic of", nation.y := "korea"]
# standardize pairs
hpairs[nation.x > nation.y, t1 := nation.y]
hpairs[nation.x > nation.y, t2 := nation.x]
hpairs[nation.x > nation.y, flag := 1]
hpairs[flag==1, nation.x := t1]
hpairs[flag==1, nation.y := t2]
hp_heat <- hpairs[,list(duration = mean(duration),nv = mean(versions)),
                  by=list(nation.x,nation.y,published)]
ggplot(hp_heat[published==0], aes(nation.x, nation.y, fill= nv)) + 
  geom_tile() +
  scale_fill_gradient(name = "Failed\nProject\nVersions",
                      low = "#FFFFFF",
                      high = "#012345")  +
  labs( y="Author 2 nation", x="Author 1 nation") 

# FIGURE 15: Duration country pair heatmap
ggplot(hp_heat[published==0], aes(nation.x, nation.y, fill= duration)) + 
  geom_tile() +
  scale_fill_gradient(name = "Failed\nProject\nDuration",
                      low = "#FFFFFF",
                      high = "#012345") +
  labs( y="Author 2 nation", x="Author 1 nation") 
